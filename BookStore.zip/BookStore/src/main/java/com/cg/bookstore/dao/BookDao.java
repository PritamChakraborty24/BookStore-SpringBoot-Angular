package com.cg.bookstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.bookstore.beans.Book;

@Repository
public interface BookDao extends JpaRepository<Book, Integer> {

	@Query(value="from Book b where b.title=:title")
	Book getBookByTitle(String title);
	
	@Query(value = "from Book b where b.author=:author")
	List<Book> getBookByAuthor(String author);
	
}
