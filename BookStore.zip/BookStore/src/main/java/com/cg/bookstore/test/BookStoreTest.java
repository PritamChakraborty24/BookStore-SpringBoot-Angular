package com.cg.bookstore.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;

import cucumber.api.junit.Cucumber;

public class BookStoreTest {

	@RunWith(Cucumber.class)
	@CucumberOptions(
			features = {"features"},
			glue = {"com.cg.bookstore.stepdefinition"},
			tags = {"@save"}
			)

	public class TestRunner {

	}

}
