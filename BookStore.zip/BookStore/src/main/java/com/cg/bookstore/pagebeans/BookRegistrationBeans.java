package com.cg.bookstore.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class BookRegistrationBeans {


	@FindBy(how=How.NAME, name="title")
	private WebElement title;
	
	@FindBy(how=How.NAME, name="author")
	private WebElement author;
	
	@FindBy(how=How.NAME, name="description")
	private WebElement description;
	
	@FindBy(how=How.NAME, name="iSBN_Number")
	private WebElement iSBN_Number;
	
	@FindBy(how=How.NAME, name="price")
	private WebElement price;
	
	@FindBy(how=How.NAME, name="publishDate")
	private WebElement publishDate;
	
	@FindBy(how=How.NAME, name="quantity")
	private WebElement quantity;
	
	@FindBy(how=How.NAME, name="category")
	private WebElement category;
	
	@FindBy(how=How.NAME, name="submit")
	private WebElement submitBtn;

	
	public BookRegistrationBeans() {
		// TODO Auto-generated constructor stub
	}
	
	public String getTitle() {
		return title.getAttribute("value");
	}

	public void setTitle(String title) {
		this.title.sendKeys(title);
	}

	public String getAuthor() {
		return author.getAttribute("value");
	}

	public void setAuthor(String author) {
		this.author.sendKeys(author);
	}
	
	


	public String getDescription() {
		return description.getAttribute("value");
	}

	public void setDescription(String description) {
		this.description.sendKeys(description);
	}

	public String getiSBN_Number() {
		return iSBN_Number.getAttribute("value");
	}

	public void setiSBN_Number(String iSBN_Number) {
		this.iSBN_Number.sendKeys(iSBN_Number);
	}

	public String getPrice() {
		return price.getAttribute("value");
	}
	
	

	public void setPrice(String price) {
		this.price.sendKeys(price);
	}

	public String getPublishDate() {
		return publishDate.getAttribute("value");
	}

	public void setPublishDate(String publishDate) {
		this.publishDate.sendKeys(publishDate);
	}

	public String getQuantity() {
		return quantity.getAttribute("value");
	}

	public void setQuantity(String quantity) {
		this.quantity.sendKeys(quantity);
	}

	public String getCategory() {
		return category.getAttribute("value");
	}

	public void setCategory(String category) {
		this.category.sendKeys(category);
	}

	public void clickSignIn() {
		submitBtn.submit();
	}
	
}
