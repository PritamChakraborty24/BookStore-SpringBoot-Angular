package com.cg.bookstore.services;

import java.util.List;

import com.cg.bookstore.beans.Book;
import com.cg.bookstore.exceptions.BookDetailsNotFoundException;

public interface BookService {
	Book acceptBookDetails(Book book);
	Book getBookDetailsByBookId(int bookId)throws BookDetailsNotFoundException;
	List<Book> getAllBookDetails() throws BookDetailsNotFoundException;
	Book getBookDetailsByName(String name) throws BookDetailsNotFoundException;
	List<Book> getBookDetailsByAuthorName(String authorName) throws BookDetailsNotFoundException;
	boolean removeBookDetails(String title) throws BookDetailsNotFoundException;
	//List<Book> getBookDetailsByCategory(String categoryName) throws BookDetailsNotFoundException;
}
